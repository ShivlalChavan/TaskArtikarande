package com.alphamobi.aarti.arti_karande_task;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;

/**
 * Created by Aarti on 1/21/2019.
 */

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {

    ArrayList<MyData> list;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title,email,address;

        public MyViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.textViewMovieName);
            email = (TextView) view.findViewById(R.id.txt_email);
            address = (TextView) view.findViewById(R.id.txt_address);
        }
    }

    public RecyclerAdapter(Context context,ArrayList<MyData> list) {
        this.context=context;
        this.list = list;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerview, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        MyData details=list.get(position);
        holder.title.setText(details.getName());
        holder.email.setText(details.getEmail());
        holder.address.setText(details.getAddress());

        Log.e("adapter",""+list.size());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}




