package com.alphamobi.aarti.arti_karande_task;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<MyData> myData;
    RecyclerAdapter recyclerAdapter;
    ProgressDialog loading;
    ApiInterface apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        getWebApi();

    }

    private void init() {

        apiService = ApiClient.getClient().create(ApiInterface.class);
        recyclerView = (RecyclerView)findViewById(R.id.recyclerview1);
        myData = new ArrayList<>();

    }

    private void getWebApi() {

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        loading = ProgressDialog.show(this,"Please wait","loading",false);
        Call<ArrayList<MyData>> call = apiService.getUsers();
        call.enqueue(new Callback<ArrayList<MyData>>() {

            @Override
            public void onResponse(Call<ArrayList<MyData>> call, Response<ArrayList<MyData>> response) {

                loading.dismiss();

                if (response.body().equals("null") || response.body().isEmpty()){

                    Toast.makeText(MainActivity.this, "No response", Toast.LENGTH_SHORT).show();
                }

                else {

                    myData = response.body();
                    Log.d("TAG", "Response = " + myData);
                    recyclerAdapter = new RecyclerAdapter(getApplicationContext(), myData);
                    recyclerView.setAdapter(recyclerAdapter);

                    Toast.makeText(MainActivity.this, "Response load successfully", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<ArrayList<MyData>> call, Throwable t) {
                loading.dismiss();
                Log.e("Mainactivity","Response = "+t.toString());
            }
        });

    }
}
