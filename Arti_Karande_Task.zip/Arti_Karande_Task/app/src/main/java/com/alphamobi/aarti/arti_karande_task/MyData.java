package com.alphamobi.aarti.arti_karande_task;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Aarti on 1/21/2019.
 */

public class MyData {

    private String name;

    @SerializedName("title")
    private String title;
    @SerializedName("email")
    private String email;
    @SerializedName("username")
    private String address;


    public MyData(String title,String email,String address) {
        this.title = title;
        this.email = email;
        this.address = address;

    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
