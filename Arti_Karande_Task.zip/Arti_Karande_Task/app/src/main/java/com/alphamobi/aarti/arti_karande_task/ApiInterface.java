package com.alphamobi.aarti.arti_karande_task;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by Aarti on 1/21/2019.
 */

public interface ApiInterface {

    @GET("users")
    Call<ArrayList<MyData>> getUsers();
}